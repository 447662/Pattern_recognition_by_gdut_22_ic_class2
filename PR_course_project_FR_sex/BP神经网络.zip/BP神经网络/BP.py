import os
import pickle
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, TensorDataset

# 设置要检查的目录
pkl_dir = r"D:\Aa-School\BP\graphs"

# 获取目录中的所有 .pkl 文件
pkl_files = [f for f in os.listdir(pkl_dir) if f.endswith('.pkl')]

# 初始化数据列表
X = []
y = []

# 遍历每个 .pkl 文件并检查其内容
for pkl_file in pkl_files:
    pkl_path = os.path.join(pkl_dir, pkl_file)
    try:
        # 加载 .pkl 文件
        with open(pkl_path, "rb") as f:
            loaded_graph_data = pickle.load(f)

        # 假设标签 y 存储在 loaded_graph_data.y, 特征 x 存储在 loaded_graph_data.x
        X.append(loaded_graph_data.x.flatten().numpy())  # 将节点特征展平为 1D 并转换为 NumPy
        y.append(loaded_graph_data.y.item())  # 假设标签是单个值

    except Exception as e:
        print(f"无法加载文件 {pkl_file}: {e}")

# 将数据转换为 NumPy 数组
X = np.array(X)
y = np.array(y)

# 数据标准化
scaler = StandardScaler()
X = scaler.fit_transform(X)

# 将数据拆分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 将数据转换为 PyTorch 张量
X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train, dtype=torch.long)
y_test_tensor = torch.tensor(y_test, dtype=torch.long)

# 创建 DataLoader 用于批处理训练数据
train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
test_dataset = TensorDataset(X_test_tensor, y_test_tensor)

train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)


# BP 神经网络模型
class BP_NeuralNetwork(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(BP_NeuralNetwork, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)  # 第一层
        self.fc2 = nn.Linear(hidden_size, output_size)  # 输出层

    def forward(self, x):
        x = torch.relu(self.fc1(x))  # 激活函数 ReLU
        x = self.fc2(x)  # 输出层
        return x


# 初始化模型参数
input_size = X_train.shape[1]  # 特征维度
hidden_size = 128  # 隐藏层节点数
output_size = len(set(y))  # 自动识别输出类别数量

# 创建模型实例
model = BP_NeuralNetwork(input_size, hidden_size, output_size)

# 损失函数和优化器
criterion = nn.CrossEntropyLoss()  # 适用于多分类问题
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 训练过程
epochs = 50
for epoch in range(epochs):
    model.train()
    running_loss = 0.0
    for inputs, labels in train_loader:
        # 前向传播
        outputs = model(inputs)
        loss = criterion(outputs, labels)

        # 反向传播
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        running_loss += loss.item()

    # 打印每一轮的损失
    print(f"Epoch [{epoch + 1}/{epochs}], Loss: {running_loss / len(train_loader):.4f}")

# 评估模型
model.eval()  # 设置为评估模式
with torch.no_grad():
    # 预测
    y_pred = []
    y_true = []
    for inputs, labels in test_loader:
        outputs = model(inputs)
        _, predicted = torch.max(outputs, 1)  # 获取预测的类别
        y_pred.extend(predicted.numpy())
        y_true.extend(labels.numpy())

# 性能评估
accuracy = accuracy_score(y_true, y_pred)
precision = precision_score(y_true, y_pred, average='binary', zero_division=1)
recall = recall_score(y_true, y_pred, average='binary', zero_division=1)
f1 = f1_score(y_true, y_pred, average='binary', zero_division=1)

print(f"准确率: {accuracy:.4f}")
print(f"精确度: {precision:.4f}")
print(f"召回率: {recall:.4f}")
print(f"F1 分数: {f1:.4f}")

# 分类别评估
classes = set(y_true)
for cls in classes:
    cls_indices = np.where(np.array(y_true) == cls)[0]
    cls_accuracy = accuracy_score(np.array(y_true)[cls_indices], np.array(y_pred)[cls_indices])
    print(f"类别 {cls} 预测准确率: {cls_accuracy:.4f}")
